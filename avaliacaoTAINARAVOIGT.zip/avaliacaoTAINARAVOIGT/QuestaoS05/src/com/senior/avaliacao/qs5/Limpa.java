package com.senior.avaliacao.qs5;

public class Limpa implements ILimpa{

	public static void main(String[] args) {
		new Limpa().limpar("O rato roeu a roupa do rei de roma", "ro");
	}

	@Override
	public String limpar(String string, String substring) {
		System.out.println("Entrada: " + string);
		System.out.println("Limpar: " + substring);
		String retorno = string;

		while (instr(retorno, substring) > -1) {
			retorno = limpa(retorno, instr(retorno, substring), substring);
		}
		System.out.println("Resultado: " + retorno);

		return "";
	}
	
	private int instr(final String str, final String cont) {
        char[] strC = str.toCharArray();
        char[] contC = cont.toCharArray();

        int initPos = -1;
        int contadorPosic = 0;

        //percorre a string e verifica se h� ocorr�ncia da substring na string
        for (int i = 0; i < strC.length; i++) {
            if (strC[i] == contC[0] && initPos == -1) {
                initPos = i;
                contadorPosic++;
            } else if (initPos > -1 && strC[i] == contC[contadorPosic]) {
                contadorPosic++;
            } else if (initPos > -1 && strC[i] != contC[contadorPosic]) {
                initPos = -1;
                contadorPosic = 0;
            }
            //caso a substring inteira tenha sido encontrada na string, retorna a posi��o em que se 
            //encontra o primeiro caracter da substring na string
            if (contadorPosic == contC.length) {
                return initPos;
            }
        }
        return initPos + cont.length() > str.length() ? -1 : initPos;
    }

    private String limpa(final String str, final int posInit, final String old) {
        String novaString;
        //constr�i a nova string, sem as ocorr�ncias da substring na string.
        novaString = substr(str, 0, posInit)
                + (substr(str, posInit + old.toCharArray().length > str.toCharArray().length ? str.toCharArray().length : posInit + old.toCharArray().length, str.toCharArray().length));
        return novaString;
    }

    private String substr(final String str, final int posInit, final int posFinal) {
        char[] value = str.toCharArray();
        if (posInit < 0) {
            throw new StringIndexOutOfBoundsException(posInit);
        }
        int subLen = posFinal - posInit;

        return ((posInit == 0) && (posFinal == value.length)) ? str
                : new String(value, posInit, subLen);
    }

}

