package com.senior.avaliacao.qs9;

public interface IFormatador {

	String formatar(double num);

}