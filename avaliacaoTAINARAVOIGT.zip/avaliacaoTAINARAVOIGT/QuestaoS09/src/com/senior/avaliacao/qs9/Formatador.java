package com.senior.avaliacao.qs9;

import java.util.Scanner;

public class Formatador implements IFormatador{

	static Scanner s = new Scanner(System.in);
	static double num;
	static String res="";
	
	public static void main(String[] args) {
		System.out.println("informe um n�mero para ser formatado");
        num = s.nextDouble();
		res = new Formatador().formatar(num);
		System.out.println(res);
	}

	@Override
	public String formatar(double num) {
		//converte o n�mero de double para string
		String aux = String.valueOf(num);
		StringBuilder stringBuilder = new StringBuilder(aux.replace(".", ","));	
		
		//verifica qual a posi��o da v�rgula
		int tamanho = stringBuilder.indexOf(",");

		System.out.println(tamanho);
		if (tamanho>3) {
			//enquanto o tamanho for maior que 3, insere-se o ponto
			//exemplo: 1000000,00 -> 1000.000,00 -> 1.000.000,00
		   while(tamanho>3) {			
		    stringBuilder.insert(tamanho-3, ".");
		    tamanho = tamanho-3;  
		   }
		}
		
		return stringBuilder.toString();
	}

}
