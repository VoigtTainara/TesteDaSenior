package com.senior.avaliacao.qs8;

public interface IJurosCompostos {
	double calcularValorFinal(double valorInicial, double juros, int parcelas);
}
