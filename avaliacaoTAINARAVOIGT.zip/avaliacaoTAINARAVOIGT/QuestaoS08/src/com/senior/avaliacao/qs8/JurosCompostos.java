package com.senior.avaliacao.qs8;

import java.text.DecimalFormat;
import java.util.Scanner;

public class JurosCompostos implements IJurosCompostos{

	static Scanner s = new Scanner(System.in);
	static double ValorInicial, Juros, ValorFinal;
	static int parcelas;
	
	
	public static void main(String[] args) {
		System.out.println("Informe o valor do empr�stimo");
		ValorInicial = s.nextDouble();
	    //utiliza o DecimalFormat para formatar em duas casas ap�s a virgula
		DecimalFormat formato = new DecimalFormat("#0.00"); 
		ValorInicial = Double.parseDouble(formato.format(ValorInicial).replace(",", "."));
		
		System.out.println("Informe o valor dos juros (0%-100%)");
		Juros = s.nextDouble();
		Juros = Juros/100;
		
		System.out.println("Informe o n�mero de parcelas");
		parcelas = s.nextInt();
		
	    ValorFinal = new JurosCompostos().calcularValorFinal(ValorInicial, Juros, parcelas);

	    ValorFinal = Double.parseDouble(formato.format(ValorFinal).replace(",", "."));
	    System.out.println(ValorFinal);
	}

    @Override
	public double calcularValorFinal(double valorInicial, double juros, int parcelas) {
		int cont=1;
		ValorFinal = ValorInicial;
		while(cont<=parcelas) {
		    ValorFinal = ValorFinal*(1+juros);
		    cont++;		
		}
		
				
	    return ValorFinal;
	}

}
//parcela = Double.valueOf(formato.format(parcela));

