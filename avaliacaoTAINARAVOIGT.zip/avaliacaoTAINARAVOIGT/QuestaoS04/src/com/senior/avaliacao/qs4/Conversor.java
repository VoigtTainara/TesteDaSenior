package com.senior.avaliacao.qs4;

import java.util.Scanner;

public class Conversor implements IConversor{

	static Scanner s = new Scanner(System.in);
	static int numdec; 
	static String numbase5;

	public static void main(String[] args) {
		System.out.println("informe um valor em base decimal");
		numdec = s.nextInt();
		if (numdec>=0) {
			numbase5 = new Conversor().converteBase5(numdec);
		}
		System.out.println(numbase5);
	}

	@Override
	public String converteBase5(int decimal) {
		int parteint = -1; 
		String guardar="", valfinal ="",valguardar="";

		while (parteint !=0) {
			//divide o n�mero por 5
			parteint = decimal/5; //24
			//se o resultado for exato, a vari�vel armazena o valor 0. Se n�o for exato, armazenar� o resto da divis�o
		
			if (decimal%5>0) {
				valguardar = String.valueOf(decimal%5);
			}else {
				valguardar = String.valueOf(0);
			}
			//armazena o resultado acima, da esquerda para a direita
			guardar = guardar+valguardar;
			//armazena a parte inteira resultante, para continuar o c�lculo (se necess�rio), at� se obter 0 como parte inteira
			decimal = parteint;
		}

		//armazena os n�meros na ordem inversa
		for (int i=guardar.length()-1; i>=0;i--) {
			valfinal = valfinal + guardar.charAt(i);
		}

		return valfinal;
	}

}

