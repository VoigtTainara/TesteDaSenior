package com.senior.avaliacao.qs4;

public interface IConversor {
	String converteBase5(int decimal);
}
