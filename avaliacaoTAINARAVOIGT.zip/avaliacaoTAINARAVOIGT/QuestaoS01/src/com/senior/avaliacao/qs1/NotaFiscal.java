package com.senior.avaliacao.qs1;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NotaFiscal implements INotaFiscal{

	static Scanner s = new Scanner(System.in);
	static int nrParcelas;
	static double valorTotal;
	static List<Double> parcelas = new ArrayList<Double>();
	
	public static void main(String[] args) {
		System.out.println("informe o n�mero de parcelas");
		nrParcelas = s.nextInt();
		System.out.println("informe o valor total das parcelas");
		valorTotal = s.nextDouble();
        parcelas = new NotaFiscal().geraParcelas(nrParcelas, valorTotal);
        
        System.out.println(parcelas);
        
	}

	@Override
	public List<Double> geraParcelas(int nrParcelas, double valorTotal) {
	    List<Double> aux = new ArrayList<Double>();
		double parcela;
	    DecimalFormat formato = new DecimalFormat("#.##"); 
	    //utiliza o DecimalFormat para formatar em duas casas ap�s a virgula
			while (nrParcelas > 0) {
				parcela = valorTotal/nrParcelas;		     
				parcela = Double.parseDouble(formato.format(parcela).replace(",", "."));
				valorTotal = valorTotal - parcela;
				aux.add(parcela); 
				nrParcelas--;
			}
			return aux;
	}
}
