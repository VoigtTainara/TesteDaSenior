package com.senior.avaliacao.qs7;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Troco implements IMaquina{
	static Scanner s = new Scanner(System.in);
	static private double troco;
	static private List<Troco> trocos = new ArrayList<Troco>();

	public enum ECedula {
		NOTA100(100), NOTA50(50), NOTA20(20), NOTA10(10), NOTA5(5), NOTA2(2), MOEDA100(
				1), MOEDA50(0.5), MOEDA25(0.25), MOEDA10(0.1), MOEDA5(0.05), MOEDA1(0.01);
		ECedula(double valor) {
			this.valor = valor;
		}
		private double valor;
		public double getValor() {	
			return valor;
		}	
	}

	private ECedula tipo;
	private int quantidade;

	public void adicionaQuantidade(int qtde) { 
		quantidade += qtde;
	}

	public Troco(ECedula tipo, int quantidade) {
		super();
		this.tipo = tipo;
		this.quantidade = quantidade;
	}
	
	public Troco() {
		
	}

	public ECedula getTipo() {	
		return tipo;
	}

	public int getQuantidade() {
		return quantidade;	
	}


	public static void main (String args[][]) {
		System.out.println("informe o troco que dever� ser recebido");
		troco = s.nextDouble();
		trocos = new Troco().montarTroco(troco);

		for (Troco t: trocos) {
			  System.out.println("Troco("+ t.getTipo().name() + ", " + t.getQuantidade()+")");
		}
		
	}

	@Override
	public List<Troco> montarTroco(Double troco){		
		List<Troco> result = new ArrayList<>();
		//armazena o valor de troco;
		double innerTroco = troco;

		//percorre todas os tipos de c�dulas
		for (Troco.ECedula cedula : Troco.ECedula.values()) {
			//enquanto o valor de troco � ser calculado for diferente de 0, calcula-se qual a quantidade de notas de 
			//determinado tipo de c�dula
			if (innerTroco != 0D) {
				int qtd = (int) (innerTroco / getValor(cedula));
				//se a quantidade de notas de determinado tipo de c�dula for diferente de 0, ent�o emcapsular� as mesmas
				//na lista de troco
				if (qtd != 0) {
					result.add(buildCedulaQtd(cedula, qtd));
					innerTroco = innerTroco % getValor(cedula);
				}
			}
		}
		return result;
	}

	private static Troco buildCedulaQtd(final Troco.ECedula cedula, final int qtd) {
		return new Troco(cedula, qtd);
	}

	private static Double getValor(final Troco.ECedula cedula) {
		return cedula.getValor();
	}

}
	
