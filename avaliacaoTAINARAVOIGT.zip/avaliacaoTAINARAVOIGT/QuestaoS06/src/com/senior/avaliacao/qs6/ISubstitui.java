package com.senior.avaliacao.qs6;

public interface ISubstitui {
	String substituir(String string, String velho, String novo);
}
