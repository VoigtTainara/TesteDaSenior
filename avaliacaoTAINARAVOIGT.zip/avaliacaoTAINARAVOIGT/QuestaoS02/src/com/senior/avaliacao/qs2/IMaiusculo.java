package com.senior.avaliacao.qs2;

public interface IMaiusculo {
	String converteMaiusculo(String par);
}
