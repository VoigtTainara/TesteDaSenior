package com.senior.avaliacao.qs2;

import java.util.Scanner;

public class Maiusculo implements IMaiusculo{

	static Scanner s = new Scanner(System.in);

	public static void main(String[] args) {

		System.out.println("informe uma frase");
		String frase = s.nextLine();
		String fraseConvertida = new Maiusculo().converteMaiusculo(frase);

		System.out.println(fraseConvertida);
	}
	
	@Override
	public String converteMaiusculo(String par) {
		String fraseFinal = "";
		String letra;
		int j;
		for (j=0; j<par.length(); j++) {
			letra = Character.toString(par.charAt(j));	
			//se a letra for a primeira da String, converte para a mai�scula
			if (j==0) {
				letra = letra.toUpperCase();
			//verifica se o caracter anterior � um espa�o ou uma v�rgula
			}else if ((par.charAt(j-1) == ' ') || (par.charAt(j-1) == ',')) {
				//verifica se o caracter atual � um espa�o ou uma v�rgula. Se n�o for, faz a convers�o para mai�sculo
				if ((par.charAt(j) != ' ') || (par.charAt(j) != ',')) {
					letra = letra.toUpperCase();
				}				
			}
			fraseFinal =  fraseFinal+letra;
		}
		return fraseFinal;	
	}
	
}