package com.senior.avaliacao.qs10;

import java.util.Scanner;
import java.util.Random;

public class JogoVelha implements IJogoVelha{

	static Scanner s = new Scanner(System.in);
	static char[][] tabuleiro = new char[3][3];
	static char verificaQuemGanhou;
	static char[][] simbolos = new char[1][2];
	static boolean jogada=false, ganhou=false;
	static int x,y, jogador=1, jogadas=0;
	static Random gerador = new Random();

	public static void main(String[] args) {
		//preenche as posi��es da matriz com _
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				tabuleiro[i][j] = '_';
			}
		}

		//preenche a matriz de s�mbolos
		simbolos[0][0]='X';
		simbolos[0][1]='O';		

		//enquanto n�o houver ganhador e o n�mero de jogadas ainda n�o for igual � 9
		while (ganhou==false && jogadas <= 9) {
			//pede a posi��o � ser preenchida
			System.out.println("Informe qual a linha (0-2) Jogador "+jogador);
			x = s.nextInt();
			while(x<0 || x>2){
				System.out.println("�ndice da linha � inv�lido. Informe novamente.");
				x = s.nextInt();
			}
			System.out.println("Informe qual a coluna (0-2) Jogador "+jogador);
			y = s.nextInt();
			while(y<0 || y>2){
				System.out.println("�ndice da coluna � inv�lido. Informe novamente. ");
				y = s.nextInt();
			}

			//caso a posi��o ainda n�o esteja preenchida com X ou O, faz o preenchimento e aumenta o n�mero de jogadas feitas.		
			if (jogador == 1) {
				try {
					if (tabuleiro[x][y]==('X') || tabuleiro[x][y]==('O')) {
						System.out.println("Posi��o j� preenchida.");                   
					} else {
						tabuleiro[x][y] = 'X';
						jogadas++;
						verificaQuemGanhou = new JogoVelha().verificaGanhador(tabuleiro);
					}
				} catch (Exception e) {
					System.out.println("Erro");
				}
			} else if (jogador==2) {
				try {
					if (tabuleiro[x][y]==('X') || tabuleiro[x][y]==('O')) {
						System.out.println("Posi��o j� preenchida.");
					} else {
						tabuleiro[x][y] = 'O';
						jogadas++;
						verificaQuemGanhou = new JogoVelha().verificaGanhador(tabuleiro);
					}
				} catch (Exception e) {
					System.out.println("Erro");
				}
			}

			System.out.println(tabuleiro[0][0] + "|"+ tabuleiro[0][1]+ "|"+ tabuleiro[0][2]);
			System.out.println(tabuleiro[1][0] + "|"+ tabuleiro[1][1]+ "|"+ tabuleiro[1][2]);
			System.out.println(tabuleiro[2][0] + "|"+ tabuleiro[2][1]+ "|"+ tabuleiro[2][2]);
			
			//verifica se houve ganhador
			if (verificaQuemGanhou!='_') {
				ganhou=true;
				if (verificaQuemGanhou=='X') {
					System.out.println("Jogador X ganhou");
				}else {
					System.out.println("Jogador Y ganhou");
				}
			}else {

			}

			//troca de jogador
			if (jogador==1) {
				jogador=2;
			}else {
				jogador=1;
			}
		}
	}





	@Override
	public char verificaGanhador(char[][] tabuleiro) throws Exception {		
		for(int x = 0; x<2;x++) {
			if((tabuleiro[0][0]==(simbolos[0][x]) && tabuleiro[1][1]==(simbolos[0][x]) && (tabuleiro[2][2])==(simbolos[0][x])) ||
					(tabuleiro[2][0]==(simbolos[0][x]) && tabuleiro[1][1]==(simbolos[0][x]) && (tabuleiro[0][2])==(simbolos[0][x])) ||
					(tabuleiro[0][0]==(simbolos[0][x]) && tabuleiro[0][1]==(simbolos[0][x]) && (tabuleiro[0][2])==(simbolos[0][x])) ||		 				
					(tabuleiro[1][0]==(simbolos[0][x]) && tabuleiro[1][1]==(simbolos[0][x]) && (tabuleiro[1][2])==(simbolos[0][x])) ||
					(tabuleiro[2][0]==(simbolos[0][x]) && tabuleiro[2][1]==(simbolos[0][x]) && (tabuleiro[2][2])==(simbolos[0][x])) ||
					(tabuleiro[0][0]==(simbolos[0][x]) && tabuleiro[1][0]==(simbolos[0][x]) && (tabuleiro[2][0])==(simbolos[0][x])) ||
					(tabuleiro[2][1]==(simbolos[0][x]) && tabuleiro[1][1]==(simbolos[0][x]) && (tabuleiro[2][1])==(simbolos[0][x])) ||
					(tabuleiro[0][2]==(simbolos[0][x]) && tabuleiro[1][2]==(simbolos[0][x])&& (tabuleiro[2][2])==(simbolos[0][x]))){
				return simbolos[0][x];
			}
		}
		return '_';
	}

}
