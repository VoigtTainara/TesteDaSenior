package com.senior.avaliacao.qs10;

public interface IJogoVelha {

	char verificaGanhador(char[][] tabuleiro) throws Exception;

}